﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Profiling
{
    class Generator
    {
        public static string GenerateDeclarations()
        {
            throw new NotImplementedException();
        }

        public static string GenerateArrayRunner()
        {
            throw new NotImplementedException();
        }
        public static string GenerateCallRunner()
        {
            throw new NotImplementedException();
        }

    }
}
