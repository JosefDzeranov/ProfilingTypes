﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using ZedGraph;

namespace Profiling
{
	class ChartBuilder
	{

	}
}